<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/Header.css">
    <title></title>
</head>
<body>

<div class="menu-area">
    <div class="menubar">
        <div class="logo">
            <a href="../view/Dashboard.php">Trust Cash</a>
        </div>
        <ul>
            <li><a href="../View/employee.php">Home</a></li>
            <li><a href="../View/employeeUpdate.php">Merchant </a></li>
            <li><a href="../View/View.php">Help</a></li>
            <li><a href="../View/PlSql.php">Procedure</a></li>
            <li><a href="../View/Food/FoodView.php">Wallet</a></li>
            <li><a href="../View/Food/FoodTrigger.php">Trigger</a></li>
            <li><a href="../Controller/Logout.php">Logout</a></li>
        </ul>
    </div>
</div>

</body>
</html>