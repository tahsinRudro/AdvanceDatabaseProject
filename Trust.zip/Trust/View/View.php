<!DOCTYPE html>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Emergency Contact</title>
	<!-- This is a comment -->
	
</head>
<body>
<center><br><br><br><br><br><br>
	<h1>For Emergency </h1>
	<center>

	Hotline: 00112233<br>

    security:999
    <br><br>


</body>
</html>